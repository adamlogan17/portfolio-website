A-level coursework 2020
-----------------------
This is the coursework which I submitted for my Computer Science A-Level and has not been changed since I handed the coursework in. 

The documentation which was produced for the coursework can be found in the 'Documentation' folder. 

Read the respective 'README.txt' files for instructions on how to run the system and the prototype. These can be found within the respective folders. 

Do not remove any of the files from the 'Final System' and 'Prototype' folders as this may break the system.
