package part01;

public interface IPlayer {
	public boolean play(AudioTrack trk);
}