package part01;

public interface ITrack {
	public String getDetails();
	public String getTitle();
	public String getArtist();
	public int getDuration();
	public String getStyle();
	public String getEncoding();
}