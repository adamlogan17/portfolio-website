Service Oriented Programming Coursework

This is my submission for the second part the coursework for my Year 2 Service Oriented Programming module.

The first part of the coursework was to design the architecture of the system.

This was a group project with 2 other members other than myself.

You must have all the services deployed on a server for the system to work. 

Please download and install the dependencies mentioned in the technical requirements section within the 'Specification for Coursework' file.
