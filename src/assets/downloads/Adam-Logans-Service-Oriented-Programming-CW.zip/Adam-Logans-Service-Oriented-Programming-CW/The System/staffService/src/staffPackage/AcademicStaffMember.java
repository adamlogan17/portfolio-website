package staffPackage;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@XmlAccessorType(XmlAccessType.FIELD)
public class AcademicStaffMember {
	private int id;
	private StaffModuleCode[] taughtMcs = new StaffModuleCode[2];
	private StaffModule[] taughtModules = new StaffModule[2];
	
	public AcademicStaffMember() {}
	
	public AcademicStaffMember(int newID) {
		this.id = newID;
	}
	
	/**
	 * Checks if the module code exists in the taughtMcs array
	 * @param mc
	 * @return - true if the module is taught by the staff member and false otherwise
	 */
	public boolean ifMcExists(StaffModuleCode mc) {
		for(StaffModuleCode enrolledMc: taughtMcs) {
			if(enrolledMc == mc) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Adds a module and the module code to the taughtModules and taughtMcs arrays
	 * @param newModule
	 */
	public void addModule(StaffModule newModule) {
		for (int i = 0; taughtMcs.length > i; i++) {
			if(taughtMcs[i] == null) {
				taughtMcs[i] = newModule.getMc();
				taughtModules[i] = newModule;
				break;
			}
		}
	}
	
	public void setId(int newId) {
		this.id = newId;
	}
	
	public int getId() {
		return id;
	}
}