package staffPackage;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import javax.jws.WebService;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

@WebService(endpointInterface="staffPackage.StaffsInterface")
public class StaffsImpl implements StaffsInterface {
	
	private final static String PATH = "StaffRegistration.xml";
	
	/**
	 * Adds a staff member to the AcademicStaffMembers object and writes the changes to the XML file
	 * @param id
	 * @throws JAXBException
	 * @throws IOException
	 */
	public void addStaff(int id) throws JAXBException, IOException {
		AcademicStaffMembers allStaff = readStaff();
		
		AcademicStaffMember newStaff = new AcademicStaffMember(id);
		allStaff.add(newStaff);
		
		writeStaff(allStaff);
	}
	
	/**
	 * Gets the AcademicStaffMembers object within the XML file
	 * @return - returns a AcademicStaffMembers object which was within the XML file
	 * @throws JAXBException
	 * @throws IOException
	 */
	public AcademicStaffMembers readStaff() throws JAXBException, IOException {
		AcademicStaffMembers allStaff = null;
		JAXBContext jAXBContext = JAXBContext.newInstance( AcademicStaffMembers.class );

		if( ! new java.io.File( PATH ).exists() ) {

			new java.io.File( PATH ).createNewFile();
			allStaff = new AcademicStaffMembers();
		}

		else {
			InputStream inputStream = new FileInputStream( PATH );
			jAXBContext = JAXBContext.newInstance( AcademicStaffMembers.class );
			Unmarshaller unmarshaller = jAXBContext.createUnmarshaller();
			allStaff = (AcademicStaffMembers) unmarshaller.unmarshal( inputStream );
		}
		
		return allStaff;
	}
	
	/**
	 * Writes an updates AcademicStaffMembers object to the XML file
	 * @param newStudents
	 * @throws JAXBException
	 * @throws IOException
	 */
	public void writeStaff(AcademicStaffMembers newStaff) throws JAXBException, IOException {
		JAXBContext jAXBContext = JAXBContext.newInstance( AcademicStaffMembers.class );
		OutputStream outputStream = new FileOutputStream( PATH );
		Marshaller marshaller = jAXBContext.createMarshaller();
		marshaller.marshal( newStaff, outputStream );
	}
	
	/**
	 * Assigns a staff member to a module
	 * @param id
	 * @param mc
	 * @param academicYear
	 * @return - It returns a 0 if it was successful and -1 if it failed
	 * @throws JAXBException
	 * @throws IOException
	 */
	public int assignModule(int id, StaffModuleCode mc, String academicYear) throws JAXBException, IOException {
		AcademicStaffMembers allStaff = readStaff();
		AcademicStaffMember staff = allStaff.getAStaffMember(id);
		StaffModule newModule = new StaffModule(mc, academicYear);
		if(!staff.ifMcExists(mc)) {
			staff.addModule(newModule);
			writeStaff(allStaff);
			return 0;
		}
		return -1;
	}
	
	/**
	 * Checks if a staff member with a particular id exists within the XML
	 * @param id
	 * @return - returns true if the staff member exists and false otherwise
	 * @throws JAXBException
	 * @throws IOException
	 */
	public boolean staffExist(int id) throws JAXBException, IOException {
		AcademicStaffMembers allStaff = readStaff();
		if(allStaff == null) {
			return false;
		} else if(allStaff.getAStaffMember(id) != null) {
			return true;
		}
		return false;
	}
}
