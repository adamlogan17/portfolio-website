package studentPackage;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@XmlAccessorType(XmlAccessType.FIELD)
public class Student {
	private int id;
	private StudentModuleCode[] enrolledMcs = new StudentModuleCode[20];
	private StudentModule[] enrolledModules = new StudentModule[20];
	
	public Student() {}
	
	public Student(int newID) {
		this.id = newID;
	}
	
	/**
	 * Adds a module and the module code to the enrolledModules and enrolledMcs arrays
	 * @param newModule
	 */
	public void addMc(StudentModule newModule) {
		for (int i = 0; enrolledMcs.length > i; i++) {
			if(enrolledMcs[i] == null) {
				enrolledMcs[i] = newModule.getMc();
				enrolledModules[i] = newModule;
				break;
			}
		}
	}
	
	/**
	 * Checks if the module code exists in the enrolledMcs array
	 * @param mc
	 * @return - true if the module is enrolled in the module and false otherwise
	 */
	public boolean ifMcExists(StudentModuleCode mc) {
		for(StudentModuleCode enrolledMc: enrolledMcs) {
			if(enrolledMc == mc) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Adds a mark to a module that the student is enrolled in
	 * @param mc
	 * @param mark
	 */
	public void addMark(StudentModuleCode mc, double mark) {
		for (int i = 0; enrolledModules.length > i; i++) {
			if(enrolledModules[i] != null) {
				if (enrolledModules[i].getMc() == mc) enrolledModules[i].addMark(mark);
			}
		}
	}
	
	/**
	 * Gets the details of a module that the student is enrolled in
	 * @param mc
	 * @return - the module code, year and mark of the module
	 */
	public String getModuleDetails(StudentModuleCode mc) {
		String result = "";
		for (int i = 0; enrolledModules.length > i; i++) {
			if(enrolledModules[i] != null) {
				if (enrolledModules[i].getMc() == mc) {
					 result = " " + enrolledModules[i].getMc() + " " + enrolledModules[i].getAcademicYear() + " " + Double.toString(enrolledModules[i].getMark());
				}
			}
		}
		return result;
	}
	
	public void setId(int newId) {
		this.id = newId;
	}
	
	public int getId() {
		return id;
	}
}