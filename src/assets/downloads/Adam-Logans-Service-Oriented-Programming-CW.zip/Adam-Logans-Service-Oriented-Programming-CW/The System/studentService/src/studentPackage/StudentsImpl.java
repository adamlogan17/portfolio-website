package studentPackage;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import javax.jws.WebService;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

@WebService(endpointInterface="studentPackage.StudentsInterface")
public class StudentsImpl implements StudentsInterface {
	
	private final static String PATH = "StudentRegistration.xml";
	
	/**
	 * Adds a student to the Students object and writes the changes to the XML file
	 * @param id
	 * @throws JAXBException
	 * @throws IOException
	 */
	public void addStudent(int id) throws JAXBException, IOException {
		Students allStudents = readStudents();

		Student newStudent = new Student(id);
		allStudents.add(newStudent);

		writeStudents(allStudents);
	}
	
	/**
	 * Gets the Students object within the XML file
	 * @return - returns a Students object which was within the XML file
	 * @throws JAXBException
	 * @throws IOException
	 */
	public Students readStudents() throws JAXBException, IOException {
		Students allStudents = null;
		JAXBContext jAXBContext = JAXBContext.newInstance( Students.class );

		if( ! new java.io.File( PATH ).exists() ) {

			new java.io.File( PATH ).createNewFile();
			allStudents = new Students();
		}

		else {
			InputStream inputStream = new FileInputStream( PATH );
			jAXBContext = JAXBContext.newInstance( Students.class );
			Unmarshaller unmarshaller = jAXBContext.createUnmarshaller();
			allStudents = (Students) unmarshaller.unmarshal( inputStream );
		}
		
		return allStudents;
	}
	
	/**
	 * Writes an updates Students object to the XML file
	 * @param newStudents
	 * @throws JAXBException
	 * @throws IOException
	 */
	public void writeStudents(Students newStudents) throws JAXBException, IOException {
		JAXBContext jAXBContext = JAXBContext.newInstance( Students.class );
		OutputStream outputStream = new FileOutputStream( PATH );
		Marshaller marshaller = jAXBContext.createMarshaller();
		marshaller.marshal( newStudents, outputStream );
	}
	
	/**
	 * Checks if a student with a particular id exists within the XML
	 * @param id
	 * @return - returns true if the student exists and false otherwise
	 * @throws JAXBException
	 * @throws IOException
	 */
	public boolean studentExists(int id) throws JAXBException, IOException {
		Students allStudents = readStudents();
		if(allStudents == null) {
			return false;
		} else if(allStudents.getAStudent(id) != null) {
			return true;
		}
		return false;
	}
	
	/**
	 * Enrolls a student onto a module
	 * @param id
	 * @param mc
	 * @param academicYear
	 * @return - It returns a 0 if it was successful and -1 if it failed
	 * @throws JAXBException
	 * @throws IOException
	 */
	public int addModule(int id, StudentModuleCode mc, String academicYear) throws JAXBException, IOException {
		Students allStudents = readStudents();
		Student newStudent = allStudents.getAStudent(id);
		StudentModule newModule = new StudentModule(mc , academicYear);
		if(!newStudent.ifMcExists(mc)) {
			newStudent.addMc(newModule);
			writeStudents(allStudents);
			return 0;
		}
		return -1;
	}
	
	/**
	 * Gives a student a mark for a module
	 * @param id
	 * @param mc
	 * @param mark
	 * @return - It returns a 0 if it was successful and -1 if it failed
	 * @throws JAXBException
	 * @throws IOException
	 */
	public int insertMark(int id, StudentModuleCode mc, double mark) throws JAXBException, IOException {
		Students allStudents = readStudents();
		Student stud = allStudents.getAStudent(id);
		if(stud.ifMcExists(mc)) {
			stud.addMark(mc, mark);
			writeStudents(allStudents);
			return 0;
		}
		return -1;
	}
	
	/**
	 * Gets the details of a module and the mark which the student recieved
	 * @param id
	 * @param mc
	 * @return - returns the mark and details of module if the student is enrolled on the module and an empty string otherwise
	 * @throws JAXBException
	 * @throws IOException
	 */
	public String printMark(int id, StudentModuleCode mc) throws JAXBException, IOException {
		String result = "";
		Students allStudents = readStudents();
		Student stud = allStudents.getAStudent(id);

		if(stud.ifMcExists(mc)) result = stud.getModuleDetails(mc);
		
		return result;
	}
}