Systems Development Coursework

This is my coursework submission for my Year 2 Software Engineering & Systems Development module. For my work on this project I was awarded the Civica award, as I achieved the highest mark within this module.

Due to the coursework being a group project, I did not complete all the work myself. I have decided to omit the names of the other 4 members of this project and I have replaced where their names where mentioned with 'XXXXX'. 
One of the team members left the project after the first semester and therefore did not contribute to the final system or the final report. The work which I did myself has been highlighted in the minutes and the peer 
assessment forms within both the reports. The details of the coursework can be found within the 'Specification for Coursework' document.
