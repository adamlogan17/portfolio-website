# web-app-person-ride-generator #

This is the test harness for the Vantiq ride management prototype. This simulates people entering a queue for particular rides and generates the length of time, in which they are willing to stay in the queue for.

### How do I get set up? ###

Simply go to the link https://peopleridegenerator.azurewebsites.net/ to use this application.