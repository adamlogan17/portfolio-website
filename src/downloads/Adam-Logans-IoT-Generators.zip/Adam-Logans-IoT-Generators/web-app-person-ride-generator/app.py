import pickle
from flask import Flask, render_template, request
from random import uniform, randint
from azureIoTManagement import *

# can add template_folder='folderName' to this to use a specific folder to hold the templates
app = Flask(__name__)

@app.route("/",methods = ['GET'])
def index():
    """This function is ran when the web app is loaded"""
    try:
        connStr = request.args.get("connStr", "")
        waitTimeRange = [float(request.args.get("minWaitTime","")), float(request.args.get("maxWaitTime",""))]
        timeMssgs = float(request.args.get("timeMssgs", ""))
        numMssgs = int(request.args.get("numMssgs", ""))
    except ValueError:
        pass # this is required to 'pass' as the above code will produce an error when the page is first loaded
             # as the arguments are empty strings and can't be converted to their respective types

    # if the connection string is empty, this means that the page has just loaded and therefore the default values should be loaded in
    if connStr:
        if timeMssgs != 0:
            timeMssgs = 1/timeMssgs # when the user enters a larger values this will increase the speed at which messages are sent
        errOccr = setUp(connStr, waitTimeRange, timeMssgs, numMssgs)
        # The below if statement is used to produce the correct message when the execution has finished 
        if errOccr:
            return "You have entered a incorrect connection string or you have no connection to Azure!"
        return "Messages Have Stopped Sending!"

    connStr = "HostName=queueHub.azure-devices.net;SharedAccessKeyName=iothubowner;SharedAccessKey=2/CCtJxeegXb2vuOXe/D0BD2U04dIcf2j4F1je5omIs="
    return render_template('index.html', prevConnStr=connStr,
        prevMinWaitTime="5", prevMaxWaitTime="25", 
        prevTimeMssgs="3", prevNumMssgs="25")

def setUp(connStr, waitTimeRange, timeMssgs, numMssgs):
    """
    This method is used for the main logic of the program
    
    Parameters
    ----------
    connStr : str
        A connection string for an IoT Hub.
    waitTimeRange : [float, float]
        A range of the values to be created for the temperature.
        The first element is the minimum value and the second element is the maximum value.
    timeMssgs : float
        The time between each message to send, in seconds.
    numMssgs : int
        The number of messages to send.
        
    Returns
    -------
    boolean
        If there are no errors False is returned but if there is an error True is returned
    """
    for i in range(1, numMssgs+1):
        rides = ["Space Hill", "Big Dipper", "Tea Cups"] # a list of the rides that are within the 'RideDetails' standard type in the ride management Vantiq prototype
        randRide = rides[randint(0, (len(rides)-1))] 
        randTime = round(uniform(waitTimeRange[0], waitTimeRange[1]),2)
        dataToBeSent = {
            "personId": i,
            "ride": randRide,
            "willingToWait": randTime 
        }
        try:
            send_telemetry_for_all_devices(connStr,data=dataToBeSent, numOfMessage=1, timeBetweenMssgs=timeMssgs)
        except Exception:
            return True
    return False

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=8080, debug=True)