# web-app-temperature-and-humidity-generator #

This is the test harness for the Vantiq temperature and humidity prototype. This will produce a random number between the values given to represent the current temperature and humidity of a device. It will also create as many of these devices as the user wishes and will delete these devices after the messages have stopped sending.

### How do I get set up? ###

Simply go to the link https://temperatureandhumiditygenerator.azurewebsites.net/ to use this application.